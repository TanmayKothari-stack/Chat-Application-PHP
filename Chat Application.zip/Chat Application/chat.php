<?php
include 'connection.php';
include 'session.php';
?>

<?php
//$id = $_GET['id'];
$email = $_SESSION['email'];
$data = mysqli_query($conn,"select * from contact_list where cemail = '$email' ");
$total = mysqli_num_rows($data);
if($total == 1)
{
while($res = mysqli_fetch_array($data))
{
	$res[7] = dechex($res[7]);
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="icon" type="image/image-x" href="icon.ico">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style4.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Chatting</title>
</head>
<body>

<div class="heading">
		<h3>Web chatting site</h3>
	</div>

<nav class="contactlist" id="contactlist">
		<div class="content">
			<ul>
				<li><i class="fa fa-phone"></i><?php 
				echo "<a href='chat.php?id=$res[7]'>$res[1]</a>"; 
			} }
			else{
				echo "No Contacts Found";
			}?>
		</li>
			</ul>
		</div>
	</nav>

	<!-- Navigation code -->

	<div class="menu" id="menu" onclick="menu()">
		<span></span>
		<span></span>
		<span></span>
	</div>

<div class="footer" id="footer">
	<ul>
		<li><a href="contact.php">Add Contact</a></li>
		<li><a href='settings.php'>Settings</a></li>		
	</ul>
</div>


<div class="container">
	<div class="content">
		<div class="heading">Welcome</div>
		<div class="chats">
			
		</div>
		<form action="" method="post">
			<textarea name="message"></textarea>
			<input type="submit" name="submit" value="Send">
		</form>
	</div>
</div>


<script type="text/javascript">
		var menubar = document.getElementById("menu");
		var contactlist = document.getElementById("contactlist");
		var footerdata = document.getElementById("footer");
		function menu()
		{
			menubar.classList.toggle("active");
			contactlist.classList.toggle("active");
			footerdata.classList.toggle("active");

		}
	</script>

	<script type="text/javascript">
		let data = document.getElementById("test");
		let content = document.getElementById("content");
		location.href("chat.php?data='' ");
	</script>

	<script type="text/javascript" src="Jquery/jquery.js"></script>

	<script type="text/javascript">

		$(document).ready(function(){
			refresh();
		});
		function refresh()
		{
			setTimeout(function(){
				$(".chats").load("chatting.php?id=<?php echo hexdec($_GET['id']); ?>")
				refresh();
		},200);

		}
	</script>

</body>
</html>
<?php

if(isset($_POST['submit']))
{
$id = hexdec($_GET['id']);
$msg = $_POST['message'];
$email = $_SESSION['email'];

$dta = mysqli_query($conn,"select * from contact_list where uemail = '$email' ");
$result = mysqli_fetch_array($dta);

$name = $result['uname'];
$email = $_SESSION['email'];
$mobile = $result['umobile'];

$cname = $result['cname'];
$cemail = $result['cemail'];
$cmobile = $result['cmobile'];

if(trim($msg))
{
$data = mysqli_query($conn,"insert into messages (uname,uemail,umobile,cname,cemail,cmobile,chatid,message) values('$name','$email','$mobile','$cname','$cemail','$cmobile','$id','$msg') ");
}
}
?>