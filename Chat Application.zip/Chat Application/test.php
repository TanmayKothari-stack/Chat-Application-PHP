<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		body
		{
			background: rgba(0, 0, 0, 0.5);
			background-blend-mode: darken;
			z-index: 1000;
		}
		img
		{
			z-index: -188;
		}
	</style>
</head>
<body>
<img src="images/background.png">
</body>
</html>