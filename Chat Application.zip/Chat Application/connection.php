<?php 
$conn = mysqli_connect($host='localhost',$user='root',$password='',$database='chatsite');
 ?>